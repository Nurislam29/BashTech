﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static float Money;

    public static float Day;
    public static float Mounth;

    public static float CountHuman;

    public static float CountChild;
    public static float CountAdult;
    public static float CountOVZ;

    public static float FormAdventure;
    public static float Opportunity;
    public static float CountStoping;

    public static float StartPos = 1;
    public static float EndPos = 2;
}
