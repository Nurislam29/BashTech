﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Mounth : MonoBehaviour
{
    private Text dataMounth;
    static public float kStat;
    float k;

    void Start()
    {
        dataMounth = GetComponent<Text>();
        k = 1;
    }

    void Update()
    {
        kStat = k;
        dataMounth.text = System.Convert.ToString(k);

        GameManager.Mounth = k;
    }

    public void UpMounth()
    {
        if (k == 12) k = 12;
        else k++;
        Day.k = 1;
    }

    public void DownMounth()
    {
        if (k == 1) k = 1;
        else k--;
        Day.k = 1;
    }
}
