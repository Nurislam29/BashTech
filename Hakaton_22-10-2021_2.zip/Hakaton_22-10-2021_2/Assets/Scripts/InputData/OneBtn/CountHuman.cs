﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class CountHuman : MonoBehaviour
{
    public static float kAll;
    private Text dataHuman;
    float kH;

    void Start()
    {
        dataHuman = GetComponent<Text>();
        kH = 1;
    }

    void Update()
    {
        dataHuman.text = System.Convert.ToString(kH);

        kAll = kH;

        GameManager.CountHuman = kH;
    }

    public void UpCount()
    {
        kH++;
        Child.k = 0;
        Human.k = 0;
        Invalited.k = 0;
    }

    public void DownCount()
    {
        if (kH == 1) kH = 1;
        else kH--;
        Child.k = 0;
        Human.k = 0;
        Invalited.k = 0;
    }
}