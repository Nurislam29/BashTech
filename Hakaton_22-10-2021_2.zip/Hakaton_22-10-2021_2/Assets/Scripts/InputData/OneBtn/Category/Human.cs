﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Human : MonoBehaviour
{
    public static float kAll;
    private Text dataHuman;
    public static float k;

    void Start()
    {
        dataHuman = GetComponent<Text>();
        k = 0;
    }

    void Update()
    {
        dataHuman.text = System.Convert.ToString(k);

        kAll = k;

        GameManager.CountAdult = k;
    }

    public void UpCount()
    {
        if (kAll + Child.kAll + Invalited.kAll < CountHuman.kAll) k++;
    }

    public void DownCount()
    {
        if (k == 0) k = 0;
        else k--;
    }
}
