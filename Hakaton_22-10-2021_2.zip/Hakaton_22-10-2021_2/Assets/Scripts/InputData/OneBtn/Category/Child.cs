﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Child : MonoBehaviour
{
    public static float kAll;
    private Text dataHuman;
    public static float k;

    void Start()
    {
        dataHuman = GetComponent<Text>();
        k = 0;
    }

    void Update()
    {
        dataHuman.text = System.Convert.ToString(k);

        kAll = k;

        GameManager.CountChild = k;
    }

    public void UpCount()
    {
        if (Human.kAll + kAll + Invalited.kAll < CountHuman.kAll) k++;
    }

    public void DownCount()
    {
        if (k == 0) k = 0;
        else k--;
    }
}
