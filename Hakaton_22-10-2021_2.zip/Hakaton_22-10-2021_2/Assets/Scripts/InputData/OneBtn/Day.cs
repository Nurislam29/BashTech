﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Day : MonoBehaviour
{
    private Text dataDay;
    public static float k;
    float max;

    void Start()
    {
        dataDay = GetComponent<Text>();
        k = 1;
        max = 1;
    }

    void Update()
    {
        dataDay.text = System.Convert.ToString(k);

        if (Mounth.kStat == 1) max = 31;
        if (Mounth.kStat == 2) max = 29;
        if (Mounth.kStat == 3) max = 31;
        if (Mounth.kStat == 4) max = 30;
        if (Mounth.kStat == 5) max = 31;
        if (Mounth.kStat == 6) max = 30;
        if (Mounth.kStat == 7) max = 31;
        if (Mounth.kStat == 8) max = 31;
        if (Mounth.kStat == 9) max = 30;
        if (Mounth.kStat == 10) max = 31;
        if (Mounth.kStat == 11) max = 30;
        if (Mounth.kStat == 12) max = 31;

        GameManager.Day = k;
    }

    public void UpDay()
    {
        if (k == max) k = max;
        else k++;
    }

    public void DownDay()
    {
        if (k == 1) k = 1;
        else k--;
    }
}
