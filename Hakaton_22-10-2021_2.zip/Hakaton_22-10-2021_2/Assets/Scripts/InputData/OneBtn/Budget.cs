﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Budget : MonoBehaviour
{
    private Text dataBudget;
    string bTxt;
    float kB = 1;

    void Start()
    {
        dataBudget = GetComponent<Text>();
        bTxt = "От 0 до 10 тыс.";
    }

    void Update()
    {
        dataBudget.text = System.Convert.ToString(bTxt);
        if (kB == 1) bTxt = "От 0 до 10 тыс.";
        if (kB == 2) bTxt = "От 10 до 20 тыс.";
        if (kB == 3) bTxt = "От 20 до 30 тыс.";
        if (kB == 4) bTxt = "От 30 до 40 тыс.";
        if (kB == 5) bTxt = "От 40 до 50 тыс.";
        if (kB == 6) bTxt = "От 50 до 60 тыс.";
        if (kB == 7) bTxt = "От 60 до 70 тыс.";
        if (kB == 8) bTxt = "От 70 до 80 тыс.";
        if (kB == 9) bTxt = "От 80 до 90 тыс.";
        if (kB == 10) bTxt = "От 90 до 100 тыс.";
        if (kB == 11) bTxt = "От 100 тыс. и более";

        GameManager.Money = kB;
    }

    public void UpBudget()
    {
        if (kB < 11) kB++;
        else kB = 1;
    }

    public void DownBudget()
    {
        if (kB > 1) kB--;
        else kB = 11;
    }
}
