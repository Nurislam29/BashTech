﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Opportunity : MonoBehaviour
{
    private Text dataYN;
    string Txt;
    float k = 1;

    void Start()
    {
        dataYN = GetComponent<Text>();
        Txt = "Да";
    }

    void Update()
    {
        dataYN.text = System.Convert.ToString(Txt);
        if (k == 1) Txt = "Да";
        if (k == 2) Txt = "Нет";

        GameManager.Opportunity = k;
    }

    public void UpOport()
    {
        if (k == 1) k++;
        else k = 1;
    }

    public void DownOport()
    {
        if (k == 2) k--;
        else k = 2;
    }
}
