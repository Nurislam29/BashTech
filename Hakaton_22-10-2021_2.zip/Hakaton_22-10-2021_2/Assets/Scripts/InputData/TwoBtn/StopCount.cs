﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class StopCount : MonoBehaviour
{
    private Text dataStop;
    float k;

    void Start()
    {
        dataStop = GetComponent<Text>();
        k = 0;
    }

    void Update()
    {
        dataStop.text = System.Convert.ToString(k);

        GameManager.CountStoping = k;
    }

    public void UpCount()
    {
        k++;
    }

    public void DownCount()
    {
        if (k == 0) k = 0;
        else k--;
    }
}
