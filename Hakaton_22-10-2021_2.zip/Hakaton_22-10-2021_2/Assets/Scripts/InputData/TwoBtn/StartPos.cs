﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class StartPos : MonoBehaviour
{
    private Text dataPos;
    string Txt;
    float k = 1;

    void Start()
    {
        dataPos = GetComponent<Text>();
        Txt = "Москва";
    }

    void Update()
    {
        dataPos.text = System.Convert.ToString(Txt);

        if (k == 2) Txt = "Анапа";
        else Txt = "Москва";

        GameManager.StartPos = k;
    }

    public void Up()
    {
        if (k == 1) k++;
        else k = 1;
    }

    public void Down()
    {
        if (k == 2) k--;
        else k = 2;
    }
}
