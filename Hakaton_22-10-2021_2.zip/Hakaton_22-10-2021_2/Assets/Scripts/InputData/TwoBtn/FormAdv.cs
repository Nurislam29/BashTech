﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class FormAdv : MonoBehaviour
{
    private Text dataForm;
    string fTxt;
    float kF = 1;

    void Start()
    {
        dataForm = GetComponent<Text>();
        fTxt = "Самолёт";
    }

    void Update()
    {
        dataForm.text = System.Convert.ToString(fTxt);
        if (kF == 1) fTxt = "Самолёт";
        if (kF == 2) fTxt = "Машина";
        if (kF == 3) fTxt = "Поезд";

        GameManager.FormAdventure = kF;
    }

    public void UpAdv()
    {
        if (kF < 3) kF++;
        else kF = 1;
    }

    public void DownAdv()
    {
        if (kF > 1) kF--;
        else kF = 3;
    }
}
