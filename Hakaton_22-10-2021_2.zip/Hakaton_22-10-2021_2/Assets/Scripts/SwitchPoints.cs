﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchPoints : MonoBehaviour
{
    public GameObject Cafe_1, Cafe_2, Cafe_3, Cafe_4, Cafe_5, Cafe_6;
    public GameObject Oil_1, Oil_2, Oil_3;
    public GameObject Hotel_1, Hotel_2;

    float sw_1 = 1;
    float sw_2 = 1;
    float sw_3 = 1;

    void Start()
    {
        Cafe_1.SetActive(true);
        Cafe_2.SetActive(false);
        Cafe_3.SetActive(false);
        Cafe_4.SetActive(false);
        Cafe_5.SetActive(false);
        Cafe_6.SetActive(false);

        Oil_1.SetActive(true);
        Oil_2.SetActive(false);
        Oil_3.SetActive(false);

        Hotel_1.SetActive(true);
        Hotel_2.SetActive(false);
    }
    void Update()
    {
        if (sw_1 == 1)
        {
            Cafe_1.SetActive(true);
            Cafe_2.SetActive(false);
            Cafe_3.SetActive(false);
            Cafe_4.SetActive(false);
            Cafe_5.SetActive(false);
            Cafe_6.SetActive(false);
        }
        if (sw_1 == 2)
        {
            Cafe_1.SetActive(false);
            Cafe_2.SetActive(true);
            Cafe_3.SetActive(false);
            Cafe_4.SetActive(false);
            Cafe_5.SetActive(false);
            Cafe_6.SetActive(false);
        }
        if (sw_1 == 3)
        {
            Cafe_1.SetActive(false);
            Cafe_2.SetActive(false);
            Cafe_3.SetActive(true);
            Cafe_4.SetActive(false);
            Cafe_5.SetActive(false);
            Cafe_6.SetActive(false);
        }
        if (sw_1 == 4)
        {
            Cafe_1.SetActive(false);
            Cafe_2.SetActive(false);
            Cafe_3.SetActive(false);
            Cafe_4.SetActive(true);
            Cafe_5.SetActive(false);
            Cafe_6.SetActive(false);
        }
        if (sw_1 == 5)
        {
            Cafe_1.SetActive(false);
            Cafe_2.SetActive(false);
            Cafe_3.SetActive(false);
            Cafe_4.SetActive(false);
            Cafe_5.SetActive(true);
            Cafe_6.SetActive(false);
        }
        if (sw_1 == 6)
        {
            Cafe_1.SetActive(false);
            Cafe_2.SetActive(false);
            Cafe_3.SetActive(false);
            Cafe_4.SetActive(false);
            Cafe_5.SetActive(false);
            Cafe_6.SetActive(true);
        }

        if (sw_2 == 1)
        {
            Oil_1.SetActive(true);
            Oil_2.SetActive(false);
            Oil_3.SetActive(false);
        }
        if (sw_2 == 2)
        {
            Oil_1.SetActive(false);
            Oil_2.SetActive(true);
            Oil_3.SetActive(false);
        }
        if (sw_2 == 3)
        {
            Oil_1.SetActive(false);
            Oil_2.SetActive(false);
            Oil_3.SetActive(true);
        }

        if (sw_3 == 1)
        {
            Hotel_1.SetActive(true);
            Hotel_2.SetActive(false);
        }
        if (sw_3 == 2)
        {
            Hotel_1.SetActive(false);
            Hotel_2.SetActive(true);
        }
    }
    public void plusCafe()
    {
        if (sw_1 < 6) sw_1++;
        else sw_1 = 1;
    }
    public void minusCafe()
    {
        if (sw_1 > 1) sw_1--;
        else sw_1 = 6;
    }
    public void plusOil()
    {
        if (sw_2 < 3) sw_2++;
        else sw_2 = 1;
    }
    public void minusOil()
    {
        if (sw_2 > 1) sw_2--;
        else sw_2 = 3;
    }
    public void plusHotel()
    {
        if (sw_3 < 2) sw_3++;
        else sw_3 = 1;
    }
    public void minusHotel()
    {
        if (sw_3 > 1) sw_3--;
        else sw_3 = 2;
    }
}
