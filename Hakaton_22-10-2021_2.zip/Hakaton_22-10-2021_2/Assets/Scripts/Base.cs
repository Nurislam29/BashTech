﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Base : MonoBehaviour
{
    public GameObject panel_1;
    public GameObject panel_2;

    void Start()
    {
        panel_1.SetActive(true);
        panel_2.SetActive(false);
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.Escape)) Application.LoadLevel("InputDataScene");
    }

    public void OnePan()
    {
        panel_1.SetActive(true);
        panel_2.SetActive(false);
    }

    public void TwoPan()
    {
        panel_1.SetActive(false);
        panel_2.SetActive(true);
    }

    public void OnClickNext()
    {
        Application.LoadLevel("Map");
    }
}
